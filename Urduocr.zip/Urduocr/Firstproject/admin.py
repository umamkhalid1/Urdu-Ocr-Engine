from django.contrib import admin
from .models import upload


admin.site.register(upload)
# Register your models here.


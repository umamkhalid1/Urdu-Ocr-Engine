from django.apps import AppConfig


class FirstprojectConfig(AppConfig):
    name = 'Firstproject'

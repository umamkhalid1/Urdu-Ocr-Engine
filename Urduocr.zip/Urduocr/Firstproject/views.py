from django.shortcuts import render
from .forms import uploadform
import os
import PIL
from PIL import Image
import pytesseract
import glob
import numpy as np
import cv2

def home(request):
    
    os.chdir (r'D:/umam/media')
    
    for f in glob.glob('*.*'):
        if f:
            f=f
    
            n,s,e=f.partition('.')
            prv=n+s+e
            #Image.open(prv)
            new='aaa'+s+e
            os.rename(prv,new)
            os.remove('aaa'+s+e)
            os.remove('new.jpg')
            os.remove('clear1.jpg')
            
    A={}        
    fetch = None
    lenth = None
    
    if request.method == 'POST':
        form = uploadform(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            #return redirect(do_tess)
    else:
        form = uploadform()                
   
    os.chdir (r'D:/umam/media')
    for f in glob.glob('*.*'):
        if f:
            f=f
    
            n,s,e=f.partition('.')
            prv=n+s+e
            Image.open(prv)
            new='aaa'+s+e
            os.rename(prv,new)
            
            #print(new)
            
            
            
            image = cv2.imread("aaa"+s+e)

            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            

            thresh = cv2.threshold(gray, 0, 255,
                cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]

            coords = np.column_stack(np.where(thresh > 0))
            angle = cv2.minAreaRect(coords)[-1]
            if angle < -45:
                angle = -(90 + angle)
            else:
                angle = -angle
                
            (h, w) = image.shape[:2]
            center = (w // 2, h // 2)
            M = cv2.getRotationMatrix2D(center, angle, 1.0)
            rotated = cv2.warpAffine(image, M, (w, h),
                flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)

            #cv2.putText(rotated,format(angle),
                #(10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 1)

            #print("[INFO] angle: {:.3f}".format(angle))
            #cv2.imshow("Input", image)
            #cv2.imshow("Rotated with character", rotated)
            #cv2.waitKey(0)

            _, threshold = cv2.threshold(rotated, 155, 255, cv2.THRESH_BINARY)
            img_gray = cv2.cvtColor(rotated, cv2.COLOR_BGR2GRAY)

            clear1 = cv2.adaptiveThreshold(img_gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 115, 55)
            clear2 = cv2.adaptiveThreshold(img_gray, 265, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 35, 5)
            cv2.imwrite('clear1.jpg',clear2)
            image=Image.open('clear1.jpg')
            image.save('new.jpg','JPEG',quality=9000)


            cv2.imshow("Rotated", rotated)
            cv2.imshow("Clear1", clear1)
            #cv2.imshow("Gaussian",clear2)
            cv2.waitKey(0)
            
            pytesseract.pytesseract.tesseract_cmd = (r'D:/Tesseract-OCR/tesseract.exe')
            img=pytesseract.image_to_string(Image.open('new.jpg'), lang='urd' )
            #text = pytesseract.image_to_string(Image.fromarray(clear1), lang='urd')
            #print(im)
            
            fetch=img.lower()
            
            a='a b c d e f g h i j k l m n o p q r s t u v w x y z'
            b=a.split(' ')
            #print("No of Alphabets "+str(c))
            
            lenth=len(img)
            for leters in b:
                        if leters in img:
                                    z=round((img.count(leters)*100/len(img)),2)
                                    A[leters]=str(z)+'%'
            
            
            
            #img=pytesseract.image_to_string(Image.open(r'D:/umam/media/'+new), lang='urd')
                #result=pytesseract.image_to_string(Image.open('hhh.JPG'), lang='urd')
                #print (img)
            os.remove('clear1.jpg')
            os.remove('aaa'+s+e)
            os.remove('new.jpg')
            #os.remove('removed_noise.jpg')
            #os.remove('thres.jpg')   
              
    return render(request, 'firstpage/index.html', {
                'form': form,
                'fetch': fetch,
                'lenth': lenth,
                'A': A
            })
    

            
    


